﻿using log4net;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using WhatToWhere.Areas.APIServices.Models;
using WhatToWhere.Filter;
using WhatToWhere.Models;
using WhereToWhere.Data;

namespace WhatToWhere.Areas.APIServices.Controllers
{

    [Route("api/post/{action}")]
    [APILogFilter]

    public class PostController : ApiController
    {
        [HttpPost]
        [SwaggerResponse(200)]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult CreatePost()
        {
            try
            {
                string filePath = "";
                tbl_post model = new tbl_post();
                model.CreatedDate = DateTime.Now;
                model.LikeCount = 0;
                model.DislikeCount = 0;

                if (HttpContext.Current.Request.Form.AllKeys.Contains("UserId"))
                {
                    model.CreatedBy = Convert.ToInt64(HttpContext.Current.Request.Form["UserId"]);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "UserId parameter is missing.");
                }
                if (HttpContext.Current.Request.Form.AllKeys.Contains("Description"))
                {
                    model.Description = Convert.ToString(HttpContext.Current.Request.Form["Description"]);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "Description parameter is missing.");
                }
                if (HttpContext.Current.Request.Form.AllKeys.Contains("ShareType"))
                {
                    model.ShareType = Convert.ToString(HttpContext.Current.Request.Form["ShareType"]);
                    if (model.ShareType.ToLower() != "public" && model.ShareType.ToLower() != "private")
                    {
                        return Content(HttpStatusCode.BadRequest, "ShareType should be 'private' or 'public'.");
                    }
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "ShareType parameter is missing.");
                }

                var file = HttpContext.Current.Request.Files.Count > 0 ? HttpContext.Current.Request.Files[0] : null;

                if (file != null && file.ContentLength > 0)
                {
                    var fileName = model.CreatedBy + "_postpic_" + Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                    var path = HttpContext.Current.Server.MapPath("~/Images/" + model.CreatedBy + "/post/");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    file.SaveAs(Path.Combine(path, fileName));
                    filePath = "www.whattowhere.net/Images/" + model.CreatedBy + "/post/" + fileName;
                    model.ImagePath = filePath;
                }

                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    _dbcontext.tbl_post.Add(model);
                    _dbcontext.SaveChanges();
                    return Ok();
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [SwaggerResponse(200, null, typeof(List<PostModel>))]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult GetMyPost(long UserId)
        {
            ResponseModel _respModel = new ResponseModel();
            try
            {
                if (UserId >= 0)
                {
                    using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                    {
                        var data = _dbcontext.tbl_post.Where(x => x.CreatedBy == UserId).OrderByDescending(x => x.CreatedDate).Select(x => new PostModel()
                        {
                            PostId = x.PostId,
                            Description = x.Description,
                            ImagePath = x.ImagePath,
                            ShareType = x.ShareType,
                            LikeCount = x.LikeCount,
                            DislikeCount = x.DislikeCount,
                            CreatedDate = x.CreatedDate,
                            CreatedBy = x.CreatedBy
                        }).ToList();
                        return Ok(data);
                    }
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "Invalid input details");
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [SwaggerResponse(200, null, typeof(List<DashboardPostModel>))]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult GetPostForDashboard(long UserId)
        {
            try
            {
                if (UserId >= 0)
                {
                    using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                    {
                        var data = _dbcontext.vw_dashboard_post.Where(x => x.UserId == 0 || x.UserId == UserId).OrderByDescending(x => x.CreatedDate).Select(x => new DashboardPostModel()
                        {
                            PostId = x.PostId,
                            Description = x.Description,
                            ImagePath = x.ImagePath,
                            ShareType = x.ShareType,
                            LikeCount = x.LikeCount,
                            DislikeCount = x.DislikeCount,
                            CreatedDate = x.CreatedDate,
                            CreatedBy = x.CreatedBy,
                            UserId = x.UserId
                        }).ToList();
                        return Ok(data);
                    }
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "Invalid input details");
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

    }
}