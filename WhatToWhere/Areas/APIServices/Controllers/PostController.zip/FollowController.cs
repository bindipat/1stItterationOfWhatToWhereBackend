﻿using log4net;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WhatToWhere.Filter;
using WhatToWhere.MergeUtility;
using WhatToWhere.Models;
using WhereToWhere.Data;

namespace WhatToWhere.Areas.APIServices.Controllers
{
    [Route("api/follow/{action}")]
    [APILogFilter]
    public class FollowController : ApiController
    {
        [HttpPost]
        [SwaggerResponse(200, null, typeof(UserFollowModel))]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult UserFollowing(long LoginUserId, long FollowingId)
        {
            try
            {
                if (LoginUserId <= 0 || FollowingId <= 0)
                {
                    return Content(HttpStatusCode.BadRequest, "Invalid input details");
                }
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var ExistingFollowingUser = _dbcontext.tbl_follow.Where(x => x.UserId == LoginUserId && x.FollowingId == FollowingId).FirstOrDefault();
                    if (ExistingFollowingUser != null)
                    {
                        return Content(HttpStatusCode.Conflict, "User already following that person.");
                    }

                    tbl_follow userFollowing = new tbl_follow
                    {
                        UserId = LoginUserId,
                        FollowingId = FollowingId
                    };

                    _dbcontext.tbl_follow.Add(userFollowing);
                    _dbcontext.SaveChanges();

                    int followingCount = _dbcontext.tbl_follow.Where(x => x.UserId == LoginUserId).ToList().Count();
                    int followerCount = _dbcontext.tbl_follow.Where(x => x.FollowingId == LoginUserId).ToList().Count();

                    UserFollowModel followModel = new UserFollowModel() { FollowerCount = followerCount, FollowingCount = followingCount };
                    return Ok(followModel);
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [SwaggerResponse(200, null, typeof(UserFollowModel))]
        [SwaggerResponse(400)]
        [SwaggerResponse(404)]
        [SwaggerResponse(500)]
        public IHttpActionResult UserUnfollowing(long LoginUserId, long UnfollowingId)
        {
            try
            {
                if (LoginUserId <= 0 || UnfollowingId <= 0)
                {
                    return Content(HttpStatusCode.BadRequest, "Invalid input details");
                }
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var ExistingFollowingUser = _dbcontext.tbl_follow.Where(x => x.UserId == LoginUserId && x.FollowingId == UnfollowingId).FirstOrDefault();
                    if (ExistingFollowingUser == null)
                    {
                        return Content(HttpStatusCode.NotFound, "User details not found.");
                    }

                    _dbcontext.tbl_follow.Remove(ExistingFollowingUser);
                    _dbcontext.SaveChanges();

                    int followingCount = _dbcontext.tbl_follow.Where(x => x.UserId == LoginUserId).ToList().Count();
                    int followerCount = _dbcontext.tbl_follow.Where(x => x.FollowingId == LoginUserId).ToList().Count();

                    UserFollowModel followModel = new UserFollowModel() { FollowerCount = followerCount, FollowingCount = followingCount };
                    return Ok(followModel);
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [SwaggerResponse(200, null, typeof(UserFollowModel))]
        [SwaggerResponse(400)]
        [SwaggerResponse(404)]
        [SwaggerResponse(500)]
        public IHttpActionResult RemoveFollower(long LoginUserId, long FollowerId)
        {
            try
            {
                if (LoginUserId <= 0 || FollowerId <= 0)
                {
                    return Content(HttpStatusCode.BadRequest, "Invalid input details");
                }
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var ExistingFollowingUser = _dbcontext.tbl_follow.Where(x => x.UserId == FollowerId && x.FollowingId == LoginUserId).FirstOrDefault();
                    if (ExistingFollowingUser == null)
                    {
                        return Content(HttpStatusCode.NotFound, "User details not found.");
                    }

                    _dbcontext.tbl_follow.Remove(ExistingFollowingUser);
                    _dbcontext.SaveChanges();

                    int followingCount = _dbcontext.tbl_follow.Where(x => x.UserId == LoginUserId).ToList().Count();
                    int followerCount = _dbcontext.tbl_follow.Where(x => x.FollowingId == LoginUserId).ToList().Count();
                    UserFollowModel followModel = new UserFollowModel() { FollowerCount = followerCount, FollowingCount = followingCount };
                    return Ok(followModel);
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [SwaggerResponse(200, null, typeof(List<UserFollowModel>))]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult GetFollowerList(long UserId)
        {
            try
            {
                if (UserId >= 0)
                {
                    using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                    {
                        var data = (from usr in _dbcontext.tbl_user
                                    join fl in _dbcontext.tbl_follow on usr.UserId equals fl.UserId
                                    where fl.FollowingId == UserId
                                    select new FollowerModel
                                    {
                                        FollowerId = usr.UserId,
                                        UserName = usr.UserName,
                                        FirstName = usr.FirstName,
                                        LastName = usr.LastName,
                                        Email = usr.Email,
                                        ProfileImage = usr.ProfileImage,
                                        isFollowing = _dbcontext.tbl_follow.Where(x => x.UserId == UserId && x.FollowingId == usr.UserId).Any()
                                    }).ToList();
                        return Ok(data);
                    }
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "Invalid input details");
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [SwaggerResponse(200, null, typeof(List<FollowingModel>))]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult GetFollowingList(long UserId)
        {
            try
            {
                if (UserId >= 0)
                {
                    using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                    {
                        var data = (from usr in _dbcontext.tbl_user
                                    join fl in _dbcontext.tbl_follow on usr.UserId equals fl.FollowingId
                                    where fl.UserId == UserId
                                    select new FollowingModel
                                    {
                                        FollowingId = usr.UserId,
                                        UserName = usr.UserName,
                                        FirstName = usr.FirstName,
                                        LastName = usr.LastName,
                                        Email = usr.Email,
                                        ProfileImage = usr.ProfileImage,
                                    }).ToList();

                        return Ok(data);
                    }
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "Invalid input details");
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [SwaggerResponse(200, null, typeof(List<UserModel>))]
        [SwaggerResponse(404)]
        [SwaggerResponse(500)]
        public IHttpActionResult SearchProfile(string str, long loginUserId)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var allstrings = str.Split(' ');
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId != loginUserId &&
                    (allstrings.Contains(x.FirstName) ||
                    allstrings.Contains(x.LastName) ||
                    allstrings.Contains(x.UserName))
                    ).ToList();
                    if (userModel != null)
                    {
                        List<UserModel> data = GetFullProfile(userModel, loginUserId);
                        return Ok(data);
                    }
                    else
                    {
                        return Content(HttpStatusCode.NotFound, "User details not found.");
                    }
                }

            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        private List<UserModel> GetFullProfile(List<tbl_user> userList, long loginUserId)
        {
            List<UserModel> finaluserList = new List<UserModel>();
            UserModel userModel;
            using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
            {
                foreach (var model in userList)
                {
                    userModel = DataMapper(model);
                    userModel.FollowingCount = _dbcontext.tbl_follow.Where(x => x.UserId == model.UserId).ToList().Count();
                    userModel.FollowerCount = _dbcontext.tbl_follow.Where(x => x.FollowingId == model.UserId).ToList().Count();
                    userModel.IsFollowing = _dbcontext.tbl_follow.Where(x => x.UserId == loginUserId && x.FollowingId == model.UserId).Any();
                    userModel.IsFollower = _dbcontext.tbl_follow.Where(x => x.UserId == model.UserId && x.FollowingId == loginUserId).Any();
                    finaluserList.Add(userModel);
                }
                return finaluserList;
            }
        }

        private UserModel DataMapper(tbl_user userModel)
        {
            UserModel returnModel = new UserModel();
            returnModel.UserId = userModel.UserId;
            returnModel.UserName = userModel.UserName;
            returnModel.Password = userModel.Password;
            returnModel.FirstName = userModel.FirstName;
            returnModel.LastName = userModel.LastName;
            returnModel.Email = userModel.Email;
            returnModel.Mobile = userModel.Mobile;
            returnModel.Gender = userModel.Gender;
            returnModel.ProfileImage = userModel.ProfileImage;
            returnModel.LoginType = userModel.LoginType;
            returnModel.IsMobileVerified = userModel.IsMobileVerified;
            returnModel.IsEmailVerified = userModel.IsEmailVerified;
            returnModel.UserType = userModel.UserType;
            returnModel.FirebaseToken = userModel.FirebaseToken;
            returnModel.IsActive = userModel.IsActive;
            returnModel.DeviceType = userModel.DeviceType;
            return returnModel;
        }

    }

}
