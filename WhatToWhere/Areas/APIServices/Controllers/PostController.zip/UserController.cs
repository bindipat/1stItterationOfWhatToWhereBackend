﻿using AutoMapper;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using WhatToWhere.Areas.APIServices.Models;
using WhatToWhere.Filter;
using WhatToWhere.MergeUtility;
using WhatToWhere.Models;
using WhereToWhere.Data;

namespace WhatToWhere.Areas.APIServices.Controllers
{
    [Route("api/user/{action}")]
    [APILogFilter]
    public class UserController : ApiController
    {
        [HttpGet]
        [SwaggerResponse(200, null, typeof(tbl_user))]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult GetVerificationCodeByEmailForSignUp(string email)
        {
            Random rnd = new Random();
            try
            {
                if (!string.IsNullOrEmpty(email))
                {
                    using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                    {
                        SignupVerificationModel responseData;
                        var data = _dbcontext.tbl_user.Where(x => x.Email == email).FirstOrDefault();
                        if (data != null)
                        {
                            responseData = new SignupVerificationModel { UserId = data.UserId, LoginType = data.LoginType, emailcode = rnd.Next(100000, 999999).ToString(), email = email };
                        }
                        else
                        {
                            responseData = new SignupVerificationModel { UserId = 0, LoginType = "", emailcode = rnd.Next(100000, 999999).ToString(), email = email };
                        }
                        return Ok(responseData);
                    }
                }
                else
                {
                    return BadRequest("Please enter email address");
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        public ResponseModel GetVerificationCodeByMobileForSignUp(string number)
        {
            ResponseModel _respModel = new ResponseModel();
            Random rnd = new Random();
            try
            {
                if (!string.IsNullOrEmpty(number))
                {
                    using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                    {
                        _respModel.issuccess = true;
                        var data = _dbcontext.tbl_user.Where(x => x.Mobile == number).FirstOrDefault();
                        if (data != null)
                        {
                            _respModel.data = new { UserId = data.UserId, LoginType = data.LoginType, mobilecode = rnd.Next(100000, 999999).ToString(), number = number };
                        }
                        else
                        {
                            _respModel.data = new { UserId = 0, LoginType = "", mobilecode = rnd.Next(100000, 999999).ToString(), number = number };
                        }
                    }
                }
                else
                {
                    _respModel.issuccess = false;
                    _respModel.message = "Please enter phone number";
                }
            }
            catch (Exception ex)
            {
                _respModel.issuccess = false;
                _respModel.message = "Something went wrong";
                _respModel.data = ex;
            }
            return _respModel;
        }

        [HttpPost]
        [ValidateModel]
        [SwaggerResponse(200, null, typeof(UserModel))]
        [SwaggerResponse(201, null, typeof(UserModel))]
        [SwaggerResponse(409, "Email already registered.")]
        [SwaggerResponse(500)]
        public IHttpActionResult SignUpUser(NewUserModel model)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    UserModel responseModel;
                    var ExistingUser = _dbcontext.tbl_user.Where(x => x.Email == model.Email && model.LoginType != "normal").FirstOrDefault();
                    if (ExistingUser != null)
                    {
                        ExistingUser.FirebaseToken = model.FirebaseToken;
                        ExistingUser.DeviceType = model.DeviceType;
                        _dbcontext.SaveChanges();

                        responseModel = GetFullProfile(ExistingUser);
                        return Ok(responseModel);
                    }
                    var isRecordExists = _dbcontext.tbl_user.Any(x => x.Email == model.Email && model.LoginType == "normal");
                    if (isRecordExists)
                    {
                        //return StatusCode(HttpStatusCode.Conflict())
                        return Content(HttpStatusCode.Conflict, "Email already registered.");
                    }

                    if (model.LoginType == "normal")
                    {
                        model.Gender = "";
                        model.ProfileImage = "www.whattowhere.net/images/default.jpg";
                    }

                    tbl_user userModel = new tbl_user
                    {
                        UserName = model.UserName,
                        Password = model.Password,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        Email = model.Email,
                        Mobile = "",
                        Gender = (string.IsNullOrEmpty(model.Gender) ? "" : model.Gender),
                        ProfileImage = model.ProfileImage,
                        LoginType = model.LoginType,
                        IsMobileVerified = false,
                        IsEmailVerified = model.IsEmailVerified,
                        UserType = model.UserType,
                        FirebaseToken = model.FirebaseToken,
                        IsActive = true,
                        DeviceType = model.DeviceType
                    };
                    _dbcontext.tbl_user.Add(userModel);
                    _dbcontext.SaveChanges();

                    responseModel = GetFullProfile(userModel);
                    return Content(HttpStatusCode.Created, responseModel);
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [ValidateModel]
        [SwaggerResponse(200, null, typeof(UserModel))]
        [SwaggerResponse(302)]
        [SwaggerResponse(500)]
        public IHttpActionResult SignInUser(UserSignInModel model)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    UserModel responseModel;
                    if (model.LoginType.ToLower() == "normal")
                    {
                        var userModel = _dbcontext.tbl_user.Where(x => x.IsActive && x.Email == model.Email && x.Password == model.Password).FirstOrDefault();
                        if (userModel != null)
                        {
                            userModel.FirebaseToken = model.FirebaseToken;
                            userModel.DeviceType = model.DeviceType;
                            _dbcontext.SaveChanges();
                            responseModel = GetFullProfile(userModel);
                            return Ok(responseModel);
                        }
                        else
                        {
                            return Content(HttpStatusCode.Found, "Invalid email or password.");
                        }
                    }
                    else
                    {
                        var userModel = _dbcontext.tbl_user.Where(x => x.IsActive && x.Email == model.Email).FirstOrDefault();
                        if (userModel != null)
                        {
                            userModel.FirebaseToken = model.FirebaseToken;
                            userModel.DeviceType = model.DeviceType;
                            _dbcontext.SaveChanges();
                            responseModel = GetFullProfile(userModel);
                            return Ok(responseModel);
                        }
                        else
                        {
                            return Content(HttpStatusCode.Found, "Invalid email or password.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [SwaggerResponse(200)]
        [SwaggerResponse(404)]
        [SwaggerResponse(500)]
        public IHttpActionResult SignOutUser(long UserId)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId == UserId).FirstOrDefault();
                    if (userModel != null)
                    {
                        userModel.FirebaseToken = null;
                        _dbcontext.SaveChanges();
                        return Ok();
                    }
                    else
                    {
                        return Content(HttpStatusCode.NotFound, "Invalid email.");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [SwaggerResponse(200)]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult ForgotPassword(ForgotPasswordModel model)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId == model.UserId).FirstOrDefault();
                    if (userModel != null)
                    {
                        if (userModel.LoginType != "normal")
                        {
                            return Content(HttpStatusCode.BadRequest, "Invalid Email : Social user");
                        }
                        userModel.Password = model.Password;
                        userModel.FirebaseToken = null;
                        _dbcontext.SaveChanges();
                        return Ok();
                    }
                    else
                    {
                        return Content(HttpStatusCode.BadRequest, "Invalid Email.");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [SwaggerResponse(200)]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult ResetPassword(ResetPasswordModel model)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId == model.UserId && x.Password == model.OldPassword).FirstOrDefault();
                    if (userModel != null)
                    {
                        if (userModel.LoginType != "normal")
                        {
                            return Content(HttpStatusCode.BadRequest, "Invalid Email : Social user");
                        }
                        userModel.Password = model.Newpassword;
                        _dbcontext.SaveChanges();
                        return Ok();
                    }
                    else
                    {
                        return Content(HttpStatusCode.BadRequest, "Invalid email or old password.");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [SwaggerResponse(200)]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult UpdateEmailAddress(UpdateEmailAddressModel model)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var existsData = _dbcontext.tbl_user.Any(x => x.Email == model.NewEmail);
                    if (existsData)
                    {
                        return Content(HttpStatusCode.Conflict, "Email already exists");
                    }
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId == model.UserId).FirstOrDefault();
                    if (userModel != null)
                    {
                        userModel.Email = model.NewEmail;
                        _dbcontext.SaveChanges();
                        return Ok();
                    }
                    else
                    {
                        return Content(HttpStatusCode.BadRequest, "Invalid user details.");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [SwaggerResponse(200)]
        [SwaggerResponse(409)]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult UpdateMobileNumber(UpdateMobileNumberModel model)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var existsData = _dbcontext.tbl_user.Any(x => x.Mobile == model.NewMobileNumber);
                    if (existsData)
                    {
                        return Content(HttpStatusCode.Conflict, "Mobile number already exists");
                    }
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId == model.UserId).FirstOrDefault();
                    if (userModel != null)
                    {
                        userModel.Mobile = model.NewMobileNumber;
                        _dbcontext.SaveChanges();
                        return Ok();
                    }
                    else
                    {
                        return Content(HttpStatusCode.BadRequest, "Invalid user details");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpPost]
        [SwaggerResponse(200, null, typeof(UserModel))]
        [SwaggerResponse(400)]
        [SwaggerResponse(500)]
        public IHttpActionResult EditUserProfile()
        {
            try
            {
                string filePath = "";
                EditProfileModel model = new EditProfileModel();
                if (HttpContext.Current.Request.Form.AllKeys.Contains("UserId"))
                {
                    model.UserId = Convert.ToInt64(HttpContext.Current.Request.Form["UserId"]);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "UserId parameter is missing");
                }
                if (HttpContext.Current.Request.Form.AllKeys.Contains("FirstName"))
                {
                    model.FirstName = Convert.ToString(HttpContext.Current.Request.Form["FirstName"]);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "FirstName parameter is missing");
                }
                if (HttpContext.Current.Request.Form.AllKeys.Contains("LastName"))
                {
                    model.LastName = Convert.ToString(HttpContext.Current.Request.Form["LastName"]);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "LastName parameter is missing.");
                }
                if (HttpContext.Current.Request.Form.AllKeys.Contains("Gender"))
                {
                    model.Gender = Convert.ToString(HttpContext.Current.Request.Form["Gender"]);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "Gender parameter is missing.");
                }
                if (HttpContext.Current.Request.Form.AllKeys.Contains("IsProfilePictureChanged"))
                {
                    model.IsProfilePictureChanged = Convert.ToBoolean(HttpContext.Current.Request.Form["IsProfilePictureChanged"]);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, "IsProfilePictureChanged parameter is missing.");
                }

                if (model.IsProfilePictureChanged)
                {
                    try
                    {
                        var file = HttpContext.Current.Request.Files.Count > 0 ? HttpContext.Current.Request.Files[0] : null;

                        if (file != null && file.ContentLength > 0)
                        {
                            var fileName = model.UserId + "profilepic" + ((new Random()).Next(100, 999)).ToString() + Path.GetExtension(file.FileName);
                            var path = HttpContext.Current.Server.MapPath("~/Images/" + model.UserId + "/profilepic/");
                            if (!Directory.Exists(path))
                            {
                                Directory.CreateDirectory(path);
                            }
                            else
                            {
                                System.IO.DirectoryInfo di = new DirectoryInfo(path);
                                foreach (FileInfo fl in di.GetFiles())
                                {
                                    fl.Delete();
                                }
                            }
                            file.SaveAs(Path.Combine(path, fileName));
                            filePath = "www.whattowhere.net/Images/" + model.UserId + "/profilepic/" + fileName;
                        }
                    }
                    catch (Exception ex)
                    {
                        return Content(HttpStatusCode.InternalServerError, ex);
                    }
                }

                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId == model.UserId).FirstOrDefault();
                    if (userModel != null)
                    {
                        userModel.FirstName = model.FirstName;
                        userModel.LastName = model.LastName;
                        userModel.Gender = model.Gender;
                        if (model.IsProfilePictureChanged && !string.IsNullOrEmpty(filePath))
                        {
                            userModel.ProfileImage = filePath;
                        }
                        _dbcontext.SaveChanges();
                        UserModel usermodel = GetFullProfile(userModel);
                        return Ok(usermodel);
                    }
                    else
                    {
                        return Content(HttpStatusCode.BadRequest, "Invalid user details.");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        [HttpGet]
        [SwaggerResponse(200, null, typeof(UserModel))]
        [SwaggerResponse(404)]
        [SwaggerResponse(500)]
        public IHttpActionResult GetUserDataByUserId(long UserId)
        {
            try
            {
                using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
                {
                    var userModel = _dbcontext.tbl_user.Where(x => x.UserId == UserId).FirstOrDefault();
                    if (userModel != null)
                    {
                        UserModel usermodel = GetFullProfile(userModel);
                        return Ok(usermodel);
                    }
                    else
                    {
                        return Content(HttpStatusCode.NotFound, "User details not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, ex);
            }
        }

        private UserModel GetFullProfile(tbl_user userModel)
        {
            UserModel returnModel = DataMapper(userModel);
            using (WhatToWhereDBEntities _dbcontext = new WhatToWhereDBEntities())
            {
                returnModel.FollowingCount = _dbcontext.tbl_follow.Where(x => x.UserId == userModel.UserId).ToList().Count();
                returnModel.FollowerCount = _dbcontext.tbl_follow.Where(x => x.FollowingId == userModel.UserId).ToList().Count();
                return returnModel;
            }
        }

        private UserModel DataMapper(tbl_user userModel)
        {
            UserModel returnModel = new UserModel();
            returnModel.UserId = userModel.UserId;
            returnModel.UserName = userModel.UserName;
            returnModel.Password = userModel.Password;
            returnModel.FirstName = userModel.FirstName;
            returnModel.LastName = userModel.LastName;
            returnModel.Email = userModel.Email;
            returnModel.Mobile = userModel.Mobile;
            returnModel.Gender = userModel.Gender;
            returnModel.ProfileImage = userModel.ProfileImage;
            returnModel.LoginType = userModel.LoginType;
            returnModel.IsMobileVerified = userModel.IsMobileVerified;
            returnModel.IsEmailVerified = userModel.IsEmailVerified;
            returnModel.UserType = userModel.UserType;
            returnModel.FirebaseToken = userModel.FirebaseToken;
            returnModel.IsActive = userModel.IsActive;
            returnModel.DeviceType = userModel.DeviceType;
            return returnModel;
        }
    }
}
